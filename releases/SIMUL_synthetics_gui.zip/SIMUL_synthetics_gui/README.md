# TOMO2PLT

Make synthetics:
  1. create environment `conda env create -f environment_file.yml`
  2. Modify the `synth.conf` file at your needs
  3. Play around

Please note that:
  - UNDO/REDO is not supported
  - no colorbar at the moment to specify the intensity of perturbation applied
  - **only west-positive in/out**

Cheers and enjoy

